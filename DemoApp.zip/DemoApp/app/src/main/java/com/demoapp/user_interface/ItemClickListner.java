package com.demoapp.user_interface;

public interface ItemClickListner {
    public void addItem();
    public void deleteItem();
}
