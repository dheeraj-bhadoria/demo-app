package com.demoapp;

import com.demoapp.model.User;

import java.util.ArrayList;

public class AppUtil {
    public static ArrayList<User> userList;


}
