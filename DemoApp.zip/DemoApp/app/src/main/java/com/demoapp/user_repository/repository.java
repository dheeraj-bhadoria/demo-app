package com.demoapp.user_repository;

import com.demoapp.user_interface.UserRepository;

public class repository  {

}
