package com.demoapp.user_interface;

public interface UserRepository {

    public void addUser();
    public void deleteUser(int position);

}
